//------Voor display van de tijd--------//
var today = new Date();

var seconds = today.getSeconds ();
  if (seconds <10) {
    seconds = '0' + seconds;
  }

var minutes = today.getMinutes ();
  if (minutes <10) {
      minutes = '0' + minutes;
}
document.getElementById('kloktijd').innerHTML = today.getHours() + ':' + minutes + ':' + seconds;
//-----------------------------------//

//----------- refresh----------------//
var refresh = setInterval(myTimer, 1000);

function myTimer() {
  var b = new Date();
  document.getElementById('kloktijd').innerHTML = b.toLocaleTimeString();
}
//------------------------------------//

//-----------Datum---------------//////
var maand = new Date();

document.getElementById('klok-maand').innerHTML = maand.getDate() + '/' + (maand.getMonth()+1);

// This Month
var maanden = new Array('Januari', 'Debruari', 'Maart', 'April', 'Mei', 'Juni', 'Juli', 'Augustus', 'September', 'Oktober', 'November', 'December');

document.getElementById('klok-maand').innerHTML = maand.getDate() + ' ' + maanden[maand.getMonth()] + ' ' + maand.getFullYear();



//--------------veranderende achtergrond op hoe laat het is----------//

var hour = parseInt(today.getHours());
var image = document.getElementById('klok-img').innerHTML;

function clockImg() {
  if (hour >= 0 && hour <= 5) {
      document.getElementById('klok-img').src = "images/nacht.png";

    console.log("0-5");
  } else if (hour >= 6 && hour <= 11) {
      document.getElementById('klok-img').src = "images/ochtend.png";

      console.log("6-11");
  } else if (hour >= 12 && hour <= 17) {
      document.getElementById('klok-img').src = "images/middag.png";

      console.log("12-17");
  } else if (hour >= 18 && hour <= 23){
      document.getElementById('klok-img').src = "images/avond.png";

      console.log("18-23");
  } else {
    console.log("test1234");
    console.log(hour);
  }
}

clockImg();
